﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            double mortalityRate = 0;



            Console.WriteLine("-------Welcome to NEO+Natal--------");
            Console.WriteLine("");
            Console.WriteLine("Please select your Ward");
            Console.WriteLine("Enter 1-17");
            // Note that three lines of code above will not be needed for your code this is 
            // just for understanding purposes with my example

            int wardEntry = Convert.ToInt32(Console.ReadLine());

            if (wardEntry < 1 || wardEntry > 17)
            {
                while (wardEntry < 1 || wardEntry > 17)
                {
                    Console.WriteLine("Please enter a valid input");
                    wardEntry = Convert.ToInt32(Console.ReadLine());
                }
            }   // the above code test to see if it was a valid input, if not it asks for the input again

            if (wardEntry > 0 && wardEntry < 18)
            {
                if (wardEntry == 1) { mortalityRate = mortalityRate + 53.2; }
                else if (wardEntry == 2) { mortalityRate = mortalityRate + 18.6; }
                else if (wardEntry == 3) { mortalityRate = mortalityRate + 18; }
                else if (wardEntry == 4) { mortalityRate = mortalityRate + 16.8; }
                else if (wardEntry == 5) { mortalityRate = mortalityRate + 36.8; }
                else if (wardEntry == 6) { mortalityRate = mortalityRate + 15.4; }
                else if (wardEntry == 7) { mortalityRate = mortalityRate + 19; }
                else if (wardEntry == 8) { mortalityRate = mortalityRate + 15; }
                else if (wardEntry == 9) { mortalityRate = mortalityRate + 33.4; }
                else if (wardEntry == 10) { mortalityRate = mortalityRate + 32.4; }
                else if (wardEntry == 11) { mortalityRate = mortalityRate + 20.6; }
                else if (wardEntry == 12) { mortalityRate = mortalityRate + 21.2; }
                else if (wardEntry == 13) { mortalityRate = mortalityRate + 16.2; }
                else if (wardEntry == 14) { mortalityRate = mortalityRate + 21.4; }
                else if (wardEntry == 15) { mortalityRate = mortalityRate + 38.2; }
                else if (wardEntry == 16) { mortalityRate = mortalityRate + 31.6; }
                else if (wardEntry == 17) { mortalityRate = mortalityRate + 9.6; }

                //------------------------------------------------------------------------------------------------------------

                Console.WriteLine("");
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("");
                Console.WriteLine("Please select your Ethnicity");
                Console.WriteLine("Please Enter: ");
                Console.WriteLine("1 for Aftrican-American");
                Console.WriteLine("2 for White");
                Console.WriteLine("3 for Hispanic");
                Console.WriteLine("4 for Other");

                int ethnicityEntry = Convert.ToInt32(Console.ReadLine());

                if (ethnicityEntry < 1 || ethnicityEntry > 4)
                {
                    while (ethnicityEntry < 1 || ethnicityEntry > 4)
                    {
                        Console.WriteLine("Please enter a valid input");
                        ethnicityEntry = Convert.ToInt32(Console.ReadLine());
                    }
                }   // the above code test to see if it was a valid input, if not it asks for the input again

                if (ethnicityEntry > 0 && ethnicityEntry < 5)
                {
                    if (ethnicityEntry == 1) { mortalityRate = mortalityRate + 2; }
                    else if (ethnicityEntry > 1 && ethnicityEntry < 5) { }

                } 

                //---------------------------------------------------------------------------------------------------------------

                Console.WriteLine("");
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("");
                Console.WriteLine("Have you had any previous PreMature Births?");
                Console.WriteLine("Please Enter: ");
                Console.WriteLine("1 for Yes");
                Console.WriteLine("2 for No");
                Console.WriteLine("3 for Other");

                int pre_matureEntry = Convert.ToInt32(Console.ReadLine());

                if (pre_matureEntry < 1 || pre_matureEntry > 3)
                {
                    while (pre_matureEntry < 1 || pre_matureEntry > 3)
                    {
                        Console.WriteLine("Please enter a valid input");
                        pre_matureEntry = Convert.ToInt32(Console.ReadLine());
                    }
                }   // the above code test to see if it was a valid input, if not it asks for the input again

                if (pre_matureEntry > 0 && pre_matureEntry < 4)
                {
                    if (pre_matureEntry == 1) { mortalityRate = mortalityRate + 5; }
                    else if (pre_matureEntry > 1 && pre_matureEntry < 4) { }

                } 

                //--------------------------------------------------------------------------------------------------------

                Console.WriteLine("");
                Console.WriteLine("-----------------------------------");
                Console.WriteLine("");
                Console.WriteLine("Do you have OBGYN care?");
                Console.WriteLine("Please Enter: ");
                Console.WriteLine("1 for Yes");
                Console.WriteLine("2 for No");
                Console.WriteLine("3 for Other");

                int  obgynEntry = Convert.ToInt32(Console.ReadLine());

                if (obgynEntry < 1 || obgynEntry > 3)
                {
                    while (obgynEntry < 1 || obgynEntry > 3)
                    {
                        Console.WriteLine("Please enter a valid input");
                        obgynEntry = Convert.ToInt32(Console.ReadLine());
                    }
                }   // the above code test to see if it was a valid input, if not it asks for the input again

                if (obgynEntry > 0 && obgynEntry < 4)
                {
                    if (obgynEntry == 2) { mortalityRate = mortalityRate + 4.8; }
                    else if (obgynEntry == 1 || obgynEntry == 3) { }
                } 

                // The following code is simply just to allow the console application to keep running so you can see the results
                // or to cancel it so you can run it again
                Console.WriteLine(""); 
                Console.WriteLine("Your Mortality Rate is: " + mortalityRate);
                Console.WriteLine(""); 
                Console.WriteLine("Enter y to end program");
                Console.WriteLine(""); 

                string end;

                end = Console.ReadLine();

                if (end != "y")
                {
                    while (end != "y")
                    {
                        end = Console.ReadLine();
                    }

                }

            }
        }
    }
}
